package StepDefinitions;

import java.io.IOException;

import MyntraPageObjects.HomePageObject;
import commonPageObjects.DriverManager;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class HomeStepDef {
	
	@Given("user launch myntra application")
	public void user_launch_myntra_application() throws IOException {
		DriverManager driverManager = new DriverManager();
		driverManager.launchApplication();
	}

	@When("user search the {string} product")
	public void user_search_the_product(String product) {
		HomePageObject homePageObject = new HomePageObject();
		homePageObject.SearchProduct(product);
	}
}
