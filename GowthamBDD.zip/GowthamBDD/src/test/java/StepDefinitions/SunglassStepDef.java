package StepDefinitions;

import MyntraPageObjects.HomePageObject;
import MyntraPageObjects.SunGlassPageObject;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class SunglassStepDef {
	
	@And("filter the product brand for {string} for {string}")
	public void filter_the_product_brand(String brand, String gender) {
		SunGlassPageObject sunGlassPageObject = new SunGlassPageObject();
		sunGlassPageObject.filterProduct(brand, gender);
	}
	
	@When("filter the product brand")
	public void user_search_the_product(String product) {
		HomePageObject homePageObject = new HomePageObject();
		homePageObject.SearchProduct(product);
	}
	
	@And("click first product of polaroid sunglasses")
	public void click_first_product_of_polaroid_sunglasses() {
		SunGlassPageObject sunGlassPageObject = new SunGlassPageObject();
		sunGlassPageObject.clickProduct("1");
	}
}
