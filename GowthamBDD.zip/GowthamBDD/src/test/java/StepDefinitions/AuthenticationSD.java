package StepDefinitions;

import static org.testng.Assert.assertTrue;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import pageObjects.AuthenticationPageObject;

public class AuthenticationSD extends AuthenticationPageObject{
	
	@And("user should navigate to {string} screen")
	public void user_should_navigate_to_authentication_screen(String title) {
		assertTrue(verifyAuntenticationScreenLoaded(title), "Verify User should be navigated to "+ title+ "Screen");
	}
	
	@Then("the user enter the {string} to {string}")
	public void the_user_enter_the_to_create_an_account(String emailId, String title) throws Exception {
		Thread.sleep(1000);
		enterEmailId(emailId);
		Thread.sleep(1000);
		clickCreateAccount();
		assertTrue(verifyCreateAnAccountScreenLoaded(title), "Verify Create an account screen is loaded");
	}
	
	@And("the user enters the mandatory fields and clicks on register")
	public void the_user_enters_the_mandatory_fields_and_clicks_on_register() throws Exception {
		Thread.sleep(1000);
		selectTitle("Mr");
		enterFirstName("Malik");
		enterLastName("das");
		enterPassword("feabcd");
		enterAddressDetails();
		clickButtonSubmitAccount();
		verifyMyAccountScreenLoaded("My Account");
	}
	
	@And("the user enters the {string} and {string} and clicks on sign in")
    public void the_user_enters_the_credentials_and_clicks_on_sign_in(String email, String password) throws InterruptedException {
		signIn(email,password, "My Account");
    }
}
