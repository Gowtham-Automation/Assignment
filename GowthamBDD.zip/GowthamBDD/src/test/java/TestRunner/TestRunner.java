package TestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features ="src/test/resources/Features",
glue= {"StepDefinitions"},
monochrome=true,
plugin= {"pretty","html:target/Reports/report",
		"io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"
		},
tags="@SignIn")
public class TestRunner {

}
