package MyntraPageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import commonPageObjects.CommonFunctions;
import commonPageObjects.DriverManager;


public class HomePageObject extends CommonFunctions {
	WebDriver driver;
	
	public HomePageObject() {
		this.driver = DriverManager.driver;
	}
	
	
	By search = By.xpath("//input[@placeholder='Search for products, brands and more']");
	
	public void SearchProduct(String product){
		clickElement(driver,search); 
		sendInput(driver,search,product); 
		sendInput(driver, search, Keys.ENTER);
	}

}
