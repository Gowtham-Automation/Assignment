package MyntraPageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import commonPageObjects.CommonFunctions;
import commonPageObjects.DriverManager;

public class CommonPageObject extends CommonFunctions {
	
	WebDriver driver;
	
	public CommonPageObject() {
		this.driver = DriverManager.driver;
	}
	
	By filterGenderMen = By.xpath("//input[@value='men,men women']");
	By filterGenderWomen = By.xpath("//input[@value='women,men women']");
	By brand = By.xpath("//input[@placeholder='Search for Brand']/..//*[@class='myntraweb-sprite filter-search-iconSearch sprites-search']");
	By inputBrand = By.xpath("//input[@placeholder='Search for Brand']");
	
	public void selectGender(String gender){
		if(gender.equals("Men")) {
			//clickElementJS(driver,filterGenderMen); 
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].click();", filterGenderMen.findElement(driver));
		}
		else if(gender.equals("Women"))
			clickElementJS(driver,filterGenderWomen); 
	}
	
	public void searchBrand(String brand){
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(inputBrand));
		clickElement(driver,inputBrand);
		sendInput(driver,inputBrand,brand);
	}
}
