package MyntraPageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import commonPageObjects.CommonFunctions;
import commonPageObjects.DriverManager;

public class SunGlassPageObject extends CommonFunctions {
	
	WebDriver driver;
	
	public SunGlassPageObject() {
		this.driver = DriverManager.driver;
	}
	
	public static final By searchbrand = By.xpath("//input[@placeholder='Search for Brand']/..//*[@class='myntraweb-sprite filter-search-iconSearch sprites-search']");
	public static final By inputBrandCheckbox = By.xpath("//input[@type='checkbox'][@value='Polaroid']");
	
	public void filterProduct(String brand, String gender){
		CommonPageObject commonPageObject = new CommonPageObject();
		commonPageObject.selectGender(gender);
		clickElement(driver,searchbrand);
		commonPageObject.searchBrand(brand);
		webDriverWait.until(ExpectedConditions.presenceOfElementLocated(inputBrandCheckbox));
		clickElementJS(driver,inputBrandCheckbox);
	}
	
	public void clickProduct(String item){
		final By inputBrandCheckbox = By.xpath("//ul[@class='results-base']/li["+item+"]");
		clickElement(driver,inputBrandCheckbox);
	}
}
